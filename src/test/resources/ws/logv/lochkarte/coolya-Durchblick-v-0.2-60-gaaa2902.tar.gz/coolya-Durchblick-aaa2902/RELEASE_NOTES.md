### New in 0.5
    * renamed plugin to durchblick

### New in 0.4
    * Support for MPS 2019.1

### New in 0.3
    * Support for MPS 2019.2
    * Redesigned editors based on Jos suggestions
    
### New in 0.2
    * Support for MPS 2018.2

### New in 0.1
    * Initial release


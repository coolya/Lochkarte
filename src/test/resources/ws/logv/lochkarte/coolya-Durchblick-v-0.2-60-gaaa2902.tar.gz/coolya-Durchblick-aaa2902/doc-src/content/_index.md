+++
description = "Durchblick is a plugin for JetBrains MPS that provides an alternate editor for generator templates."
title = "Durchblick for JetBrains MPS"
draft = false

+++
